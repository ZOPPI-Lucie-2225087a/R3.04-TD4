package Interface;

/**
 * Interface CreatureTerrestre
 * 
 * @see Creature
 */
public interface CreatureTerrestre {
    public void Courir();
}
