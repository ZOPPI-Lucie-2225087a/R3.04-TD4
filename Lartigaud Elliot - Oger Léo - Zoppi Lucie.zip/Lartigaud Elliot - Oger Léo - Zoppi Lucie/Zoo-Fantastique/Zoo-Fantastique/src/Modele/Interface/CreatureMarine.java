package Interface;

/**
 * Interface CreatureMarine
 * 
 * @see Creature
 */
public interface CreatureMarine {
    public void Nager();
}
