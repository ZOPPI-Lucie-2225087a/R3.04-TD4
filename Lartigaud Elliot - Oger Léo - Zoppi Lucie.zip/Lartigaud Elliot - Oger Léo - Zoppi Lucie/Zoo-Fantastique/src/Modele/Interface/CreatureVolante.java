package Interface;

/**
 * Interface CreatureVolante
 * 
 * @see Creature
 */
public interface CreatureVolante {
    public void Voler();
}
